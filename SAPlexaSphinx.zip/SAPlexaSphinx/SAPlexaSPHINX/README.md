
# sphinx-5-Maven-Example
How to use Sphinx5 basic example using Maven and automatic build for production using Maven assembly

## For more examples visit this repository -> https://github.com/goxr3plus/Java-Speech-Recognizer-Tutorial--Calculator

# Yo my bro's and si's check youtube tutorials


| About CMU Sphinx5 | Full NetBeans Tutorial |
|:-:|:-:|
| [![First](http://img.youtube.com/vi/uFoqXJvJZeM/0.jpg)](https://www.youtube.com/watch?v=uFoqXJvJZeM)  | [![Second](http://img.youtube.com/vi/UmU3yhbPIlI/0.jpg)](https://www.youtube.com/watch?v=UmU3yhbPIlI) |



