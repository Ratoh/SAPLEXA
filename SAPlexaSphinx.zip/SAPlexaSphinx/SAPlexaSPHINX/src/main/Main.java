package main;

import guiSAP.SAPlexaGUI;

public class Main {

	
	
	public static void main (String[] args) {
		SAPlexaGUI gui = new SAPlexaGUI();
		gui.open();
		
	}
	
}
